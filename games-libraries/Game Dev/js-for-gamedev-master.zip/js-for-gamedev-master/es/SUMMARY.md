# Índice


- [El entorno de trabajo](01-intro/index.md)

- JavaScript básico
    - [Programación orientada a objetos](02-javascript/0201-poo/index.md)
    - [El modelo de datos de JavaScript](02-javascript/0202-modelo-de-datos/index.md)
    - [El modelo de ejecución de JavaScript](02-javascript/0203-modelo-de-ejecucion/index.md)
    - [Ejercicios guiados](02-javascript/02-ejercicios/index.md)
    - [Práctica](02-javascript/02-practica/index.md)
        - [Guía](02-javascript/02-practica/GUIDE.md)
        - [TDD](02-javascript/02-practica/TDD.md)

- JavaScript en el navegador

    - [Navegador y DOM](03-javascript-en-el-navegador/0301-dom/index.md)
    - [Canvas](03-javascript-en-el-navegador/0302-canvas/index.md)
    - [Ejercicios guiados](03-javascript-en-el-navegador/03-ejercicios/index.md)
    - [Práctica](03-javascript-en-el-navegador/03-practica/index.md)
        - [Guía](03-javascript-en-el-navegador/03-practica/guia.md)
